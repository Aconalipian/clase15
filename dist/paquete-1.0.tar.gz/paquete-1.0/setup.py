from setuptools import setup

setup(
    name = "paquete",
    version = "1.0",
    description = "Este paquete tiene funciones para calculo matematico",
    author = "Norman Beltran",
    author_email = "nb@gmail.com",
    packages=["paquete"]
)